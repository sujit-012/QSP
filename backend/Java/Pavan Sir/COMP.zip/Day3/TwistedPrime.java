import java.util.Scanner;
class TwistedPrime 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a number : ");
		int num = sc.nextInt();
		
		boolean isPrime = true;
		
		for(int i = 2; i <= num/2; i++)
		{
			if(num % i == 0)
			{
				isPrime = false;
				break;
			}
		}
		
		if(isPrime)
		{
			int rev = 0;
			while(num > 0)
			{
				rev = rev * 10 + num % 10;
				num /= 10;
			}
				
			for(int i = 2; i <= rev/2; i++)
			{
				if(rev % i == 0)
				{
					isPrime = false;
					break;
				}
			}
			
			if(isPrime) System.out.println("Number is a twisted prime");
			else System.out.println("Number is not a twisted prime");
		}
		else
		{
			System.out.println("Number is not a twisted prime");
		}
	}
}
