import java.util.Scanner;
class PrimeBreak 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a number : ");
		int num = sc.nextInt();
		
		boolean isPrime = true;
		
		for(int i = 2; i <= num/2; i++)
		{
			if(num % i == 0)
			{
				isPrime = false;
				break;
			}
		}
		
		if(isPrime) System.out.println("Number is a prime Number");
		else System.out.println("Number is not a prime Number");
	}
}
