class FrequencyOfEvenElement 
{
	public static void main(String[] args) 
	{
		int[] a = {18, 36, 27, 81, 44, 38, 89867};
		System.out.println(freqOfEven(a));
	}
	
	public static int freqOfEven(int [] n)
	{
		int count = 0;
		
		for(int i = 0; i < n.length; i++)
		{
			if(n[i] % 2 == 0)
			{
				count++;
			}
		}
		
		return count;
	}
}
