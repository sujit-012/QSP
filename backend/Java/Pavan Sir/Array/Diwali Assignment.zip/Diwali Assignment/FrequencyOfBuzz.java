class FrequencyOfBuzz 
{
	public static void main(String[] args) 
	{
		int[] a = {7,14,17,21,27,13,14};
		System.out.println(frequencyOfBuzz(a));
	}
	
	public static int frequencyOfBuzz(int [] n)
	{
		int count = 0;
		
		for(int i = 0; i < n.length; i++)
		{
			if(n[i] % 7 == 0 || n[i] % 10 == 7)
			{
				count++;
			}
		}
		
		return count;
	}
}
