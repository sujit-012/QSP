class DitinctElement 
{
	public static void main(String[] args) 
	{
		int[] a = {1, 2, 2, 3, 1, 4};
		printDistinctEle(a);
	}
	
	public static void printDistinctEle(int [] n)
	{
		boolean [] visited = new boolean[n.length];
		
		for(int i = 0; i < n.length; i++)
		{
			if(visited[i])
			{
				continue;
			}
			
			for(int j = i + 1; j < n.length; j++)
			{
				if(n[i] == n[j])
				{
					visited[j] = true;
				}
			}
			
			System.out.println(n[i]);
		}
	}
	
}
