class IndexOfLastUniqueElement 
{
	public static void main(String[] args) 
	{
		int[] a = {5, 2, 8, 2, 5, 9, 3, 9, 4};
		System.out.println(idxOfLastUni(a));
	}
	
	public static int idxOfLastUni(int [] n)
	{
		for(int i = n.length - 1; i >= 0; i--)
		{
			int count = 1;
			
			for(int j = i - 1; j >= 0; j--)
			{
				if(n[i] == n[j])
				{
					count++;
				}
			}
			
			if(count == 1)
			{
				return i;
			}
		}
		
		return -1;
	}
			
}
