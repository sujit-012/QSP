class FrequencyOfNegetive 
{
	public static void main(String[] args) 
	{
		int [] a = {92, -19, -33, 56, -93, 37, -9};
		System.out.println(frequencyOfNeg(a));
	}
	
	public static int frequencyOfNeg(int [] n)
	{
		int count = 0;
			
		for(int i = 0; i < n.length; i++)
		{
			if(n[i] < 0)
			{
				count++;
			}
		}
		
		return count;
	}
}
